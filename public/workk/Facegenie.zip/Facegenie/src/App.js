import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Prototype from './components/Prototype';
import Home from './components/Home';
import History from './components/History';

function App() {
  return (
    <Router>
      <Routes>
       
        <Route path="/" element={<Prototype />}>
          {/* Default route redirect to /home */}
          <Route index element={<Navigate to="home" />} />

         
          <Route path="home" element={<Home />} />
          <Route path="history" element={<History />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
