import React, { useState } from 'react';
import { useNavigate, Outlet } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import '../components/styles/Prototype.css';
import { FaHome, FaHistory, FaBars } from 'react-icons/fa';
import face from '../components/assets/face.png'
import ing from '../components/assets/ing.webp'

function Prototype() {
    const [isSidebarOpen, setSidebarOpen] = useState(false);
    const navigate = useNavigate();

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);
  const location = useLocation();

  return (
    <div className="app-container">
      <div className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}>
        <div className="logo">
          <img src={face} alt="Facegenie Logo" />
        </div>
        <nav className="nav-links">
         <button
  className={`nav-button ${location.pathname === '/home' ? 'active' : ''}`}
  onClick={() => navigate('home')}
>
  <FaHome />
  <span>Home</span>
</button>

<button
  className={`nav-button ${location.pathname === '/history' ? 'active' : ''}`}
  onClick={() => navigate('history')}
>
  <FaHistory />
  <span>History</span>
</button>
        </nav>
        <div className="footer-logo">
          <img src={ing} alt="ResoluteAI" />
        </div>
      </div>

      <div className="main-content">
        <header className="top-bar">
          <button className="toggle-btn" onClick={toggleSidebar}>
           <div className="custom-bar"></div>
          </button>
          <h1>Rubber Defect Detection</h1>
        </header>
        <div className="content-body">
                 
                   <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Prototype;
